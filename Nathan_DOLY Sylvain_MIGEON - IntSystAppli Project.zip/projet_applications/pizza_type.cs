public enum pizza_type
{
tomato_sauce,
cheese_sauce,
vegan, 
margherita,
}