public enum drink_type
{
coca,
orange_juice,
apple_juice,
}