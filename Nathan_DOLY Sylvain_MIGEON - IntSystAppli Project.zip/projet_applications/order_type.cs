// enum
public enum order_type
{
    in_progress,
    in_delivery,
    delivered,
    finished,
    canceled,
}