Project - Integration System Application

Scenario 1 - Asynchronous


Members :
Nathan DOLY
Sylvain MIGEON

Digital Transformation Group - Promotion 2024


Here you have the access to our GitHub :
https://github.com/Overshadow75/projet_applications

Please do not considerate too much the commits, 
we have worked together with LiveShare.